declare namespace _default {
    let CHANGE: string;
    let ERROR: string;
    let BLUR: string;
    let CLEAR: string;
    let CONTEXTMENU: string;
    let CLICK: string;
    let DBLCLICK: string;
    let DRAGENTER: string;
    let DRAGOVER: string;
    let DROP: string;
    let FOCUS: string;
    let KEYDOWN: string;
    let KEYPRESS: string;
    let LOAD: string;
    let RESIZE: string;
    let TOUCHMOVE: string;
    let WHEEL: string;
}
export default _default;
//# sourceMappingURL=EventType.d.ts.map