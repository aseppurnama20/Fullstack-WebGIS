/**
 * @module ol/source/common
 */
/**
 * Default WMS version.
 * @type {string}
 */
export const DEFAULT_WMS_VERSION: string;
//# sourceMappingURL=common.d.ts.map